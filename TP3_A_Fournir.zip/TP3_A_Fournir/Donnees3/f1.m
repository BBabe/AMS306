function z=f1(u,x,y)
z=-y;

