function z=f2(u,x,y)
z=x;


